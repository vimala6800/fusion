import { Component } from '@angular/core';

@Component({
  selector: 'app-list-req',
  templateUrl: './list-req.component.html',
  styleUrls: ['./list-req.component.css']
})
export class ListReqComponent {

}

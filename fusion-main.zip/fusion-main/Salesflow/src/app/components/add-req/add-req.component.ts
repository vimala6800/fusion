import { Component } from '@angular/core';

@Component({
  selector: 'app-add-req',
  templateUrl: './add-req.component.html',
  styleUrls: ['./add-req.component.css']
})
export class AddReqComponent {

}
